        <style>
            .verticalLine {
              border-left: thin solid white;
            }
        </style>
        <div class="container">
            <div class="row">
            <div class="col-lg-1"></div>
                <div class="col-lg-10">
                    <div class="panel panel-info" style="background: transparent;height:400px;border: transparent;padding-top: 1%;">
                        <div class="panel-heading">
                            <!-- <h4>Registrasi Pelanggan Baru</h4> -->
                        </div>
                        <div class="panel-body">
                            <div class="row" style="text-align: center">
                                <h3 style="color: orange;font-family: serif;">Registration Coupon Number</h3>
                            </div>
                            <br>
                            <div class="row" style="text-align: center;color: white">
                                <div class="col-lg-6">
                                    <div class="panel panel-danger">
                                        <div class="panel-heading">
                                          <img src="<?php echo base_url() ?>asset/images/sk-ii-logo-red.png" class="pull-left" style="width:40px;"> <span style="margin-left: -40px">Registration</span>
                                        </div>
                                        <div class="panel-body">
                                            <h1 style="color: #e5172c;"><strong>A999</strong></h1>
                                            <a href="#" style="color: #e5172c;background-color: #f2dede;" class="btn btn-warning">Skin Check</a>
                                        </div>
                                        <div class="panel-footer">
                                            <span style="color: #e5172c;">Customer Name</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="panel panel-danger">
                                        <div class="panel-heading">
                                            <img src="<?php echo base_url() ?>asset/images/sk-ii-logo-red.png" class="pull-left" style="width:40px;"> <span style="margin-left: -40px">Registration</span>
                                        </div>
                                        <div class="panel-body">
                                            <h1 style="color: #e5172c;"><strong>B999</strong></h1>
                                            <a href="#" style="color: #e5172c;background-color: #f2dede;" class="btn btn-warning">Product Purchase</a>
                                        </div>
                                        <div class="panel-footer">
                                            <span style="color: #e5172c;">Customer Name</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                    </div>
                </div>
              </div>
          </div>
        </div>
        <div class="row" style="padding-top: 9%;text-align: center;color:white;">
                        <div class="col-lg-12">
                            <p class="copyright text-muted small" style="color:white;">Copyright &copy; Kunoir 2019.</p>
                        </div>
            </div>
    </body>
    <style>
        .error{
            color:red;
        }
    </style>
</html>