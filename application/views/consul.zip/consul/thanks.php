        <style>
            .verticalLine {
              border-left: thin solid white;
            }
        </style>
        <a href="<?php echo base_url('') ?>">
            <div class="container">
                <div class="row">
                <div class="col-lg-1"></div>
                    <div class="col-lg-10">
                        <div class="panel panel-info" style="background: transparent;height:400px;border: transparent;padding-top: 1%;">
                            <div class="panel-heading">
                                <!-- <h4>Registrasi Pelanggan Baru</h4> -->
                            </div>
                            <div class="panel-body">
                                <div class="row" style="text-align: center">
                                    <img src="<?php echo base_url() ?>asset/images/sk-ii-logo-white.png" style="height:150px">
                                    <hr>
                                    <h1 style="color: white;font-family: serif;"><strong>Thank You</strong></h1>
                                    <h3 style="color: white;font-family: serif;"> For Registering</h3>
                                </div>
                                <br>
                                <div class="row" style="text-align: center;color: white">
                                    Please wait a moment for your queuing number
                                </div>
                            
                        </div>
                    </div>
                  </div>
              </div>
            </div>
        </a>
        <div class="row" style="padding-top: 9%;text-align: center;color:white;">
                        <div class="col-lg-12">
                            <p class="copyright text-muted small" style="color:white;">Copyright &copy; Kunoir 2019.</p>
                        </div>
            </div>
    </body>
    <style>
        .error{
            color:red;
        }
    </style>
</html>