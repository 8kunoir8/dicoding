        <style>
            .verticalLine {
              border-left: thin solid white;
            }
        </style>
        
        <div class="container">
            <div class="row"">
                <div class="col-lg-12">
                    <div class="col-lg-9" style="background:#f2dede;height:275px;border-width: thick;border-color: white;text-align: center">
                        <div class="row">
                            <small class="pull-left" style="color: #e5172c;margin-left:1%;margin-top:2%;font-size:20px"><strong>Skin Consultation</strong></small>
                        </div>
                        <hr>
                        <div class="row">
                            <span style="color: #e5172c;font-size: 115px;">A001 <span class="fa fa-arrow-circle-right"></span> C1</span>
                        </div>
                    </div>
                    <div class="col-lg-2" style="background:#f2dede;height:275px;border-width: thick;border-color: white;text-align: center;margin-left:10px">
                        <div class="row">
                            <small class="pull-left" style="color: #e5172c;font-size:20px;margin-top: 9%;margin-left: 5%;"><strong>Next</strong></small>
                        </div>
                        <hr>
                        <div class="row" style="margin-top:5%">
                            <span style="color: #e5172c;font-size: 60px;">A002</span>
                        </div>  
                        <div class="row" style="margin-top:5%">
                            <span style="color: #e5172c;font-size: 60px;">A003</span>
                        </div>        
                    </div>
                </div>
            </div>
            <div class="row" style="margin-top: 1%;">
                <div class="col-lg-12">
                    <div class="col-lg-9" style="background:#f2dede;height:275px;border-width: thick;border-color: white;text-align: center">
                        <div class="row">
                            <small class="pull-left" style="color: #e5172c;margin-left:1%;margin-top:2%;font-size:20px"><strong>Product Purchase</strong></small>
                        </div>
                        <hr>
                        <div class="row">
                            <span style="color: #e5172c;font-size: 115px;">B001 <span class="fa fa-arrow-circle-right"></span> P1</span>
                        </div>
                    </div>
                    <div class="col-lg-2" style="background:#f2dede;height:275px;border-width: thick;border-color: white;text-align: center;margin-left:10px">
                        <div class="row">
                            <small class="pull-left" style="color: #e5172c;font-size:20px;margin-top: 9%;margin-left: 5%"><strong>Next</strong></small>
                        </div>
                        <hr>
                        <div class="row" style="margin-top:5%">
                            <span style="color: #e5172c;font-size: 60px;">B002</span>
                        </div>       
                        <div class="row" style="margin-top:5%">
                            <span style="color: #e5172c;font-size: 60px;">B003</span>
                        </div>        
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="text-align: center;color:white;">
                        <div class="col-lg-12">
                            <p class="copyright text-muted small" style="color:white;">Copyright &copy; Kunoir 2019.</p>
                        </div>
            </div>
    </body>
    <style>
        .error{
            color:red;
        }
    </style>
</html>